"""
Orbital Coherence Function (OCF) — Keplerian Consistency Method
================================================================
Based on: Maia, K. (2026). "The Orbital Coherence Function: A Keplerian
Consistency Method for Accelerated Orbit Determination."

Core identity exploited:
    K = G'/G = p/r = 1 + e·cos(θ)

where G' ≡ ω²r³/M is the instantaneous gravitational coupling.
"""

from .keplerian import KeplerianIndex, relational_invariant
from .propagator import KeplerPropagator
from .ocf import OCF, compute_ocf_ensemble
from .candidates import CandidateOrbit, generate_ensemble
from .filters import filter_candidates

__version__ = "0.1.0"
__author__ = "Karlos Maia"
__all__ = [
    "KeplerianIndex", "relational_invariant",
    "KeplerPropagator",
    "OCF", "compute_ocf_ensemble",
    "CandidateOrbit", "generate_ensemble",
    "filter_candidates",
]
