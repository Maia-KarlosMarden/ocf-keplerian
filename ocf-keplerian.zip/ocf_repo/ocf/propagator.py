"""
propagator.py — Two-body Keplerian orbit propagator.

Propagates a Keplerian orbit from a reference epoch using the
universal variable / Kepler equation approach. Pure two-body; no
perturbations (see Eq. 11 of Maia 2026 for the perturbed extension).
"""

import numpy as np
from scipy.optimize import brentq
from .keplerian import G_NEWTON, M_SUN, AU


class KeplerPropagator:
    """
    Exact two-body propagator for elliptical orbits.

    Parameters
    ----------
    a   : semi-major axis [m]
    e   : eccentricity
    i   : inclination [rad]
    Omega : longitude of ascending node [rad]
    omega_arg : argument of perihelion [rad]
    M0  : mean anomaly at epoch [rad]
    t0  : reference epoch [s]
    M_central : central body mass [kg]
    """

    def __init__(self, a, e, i=0.0, Omega=0.0, omega_arg=0.0,
                 M0=0.0, t0=0.0, M_central=M_SUN):
        self.a         = a
        self.e         = e
        self.i         = i
        self.Omega     = Omega
        self.omega_arg = omega_arg
        self.M0        = M0
        self.t0        = t0
        self.M_central = M_central

        self.p      = a * (1.0 - e**2)
        self.n      = np.sqrt(G_NEWTON * M_central / a**3)   # mean motion [rad/s]
        self.T_orb  = 2.0 * np.pi / self.n                    # period [s]
        self.h      = np.sqrt(G_NEWTON * M_central * self.p)  # ang. momentum

    # ------------------------------------------------------------------
    # Core solver
    # ------------------------------------------------------------------

    def _mean_anomaly(self, t: float) -> float:
        return (self.M0 + self.n * (t - self.t0)) % (2 * np.pi)

    @staticmethod
    def _solve_kepler(M: float, e: float, tol: float = 1e-12) -> float:
        """Solve M = E - e·sin(E) for eccentric anomaly E [rad]."""
        # Initial guess
        E0 = M + e * np.sin(M) / (1.0 - np.sin(M + e) + np.sin(M))
        f  = lambda E: E - e * np.sin(E) - M
        try:
            E = brentq(f, E0 - np.pi, E0 + np.pi, xtol=tol)
        except ValueError:
            E = brentq(f, 0.0, 2 * np.pi, xtol=tol)
        return E

    @staticmethod
    def _E_to_theta(E: float, e: float) -> float:
        """Convert eccentric anomaly to true anomaly [rad]."""
        return 2.0 * np.arctan2(
            np.sqrt(1 + e) * np.sin(E / 2.0),
            np.sqrt(1 - e) * np.cos(E / 2.0)
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def state_at(self, t: float) -> dict:
        """
        Compute instantaneous orbital state at time t [s].

        Returns
        -------
        dict with keys: t, theta, r, omega, K, G_prime, E, M_anom
        """
        M_anom = self._mean_anomaly(t)
        E      = self._solve_kepler(M_anom, self.e)
        theta  = self._E_to_theta(E, self.e)

        r      = self.p / (1.0 + self.e * np.cos(theta))
        omega  = self.h / r**2                           # angular velocity [rad/s]
        K      = 1.0 + self.e * np.cos(theta)            # = p/r
        G_prime = (omega**2 * r**3) / self.M_central

        return {
            "t":       t,
            "theta":   theta,
            "r":       r,
            "r_AU":    r / AU,
            "omega":   omega,
            "K":       K,
            "G_prime": G_prime,
            "E":       E,
            "M_anom":  M_anom,
        }

    def ephemeris(self, times) -> list[dict]:
        """Compute state at each time in iterable `times`."""
        return [self.state_at(t) for t in times]

    def keplerian_index_series(self, times) -> np.ndarray:
        """Return K = p/r at each epoch in `times`."""
        return np.array([self.state_at(t)["K"] for t in times])

    @property
    def elements(self) -> dict:
        return {
            "a": self.a, "e": self.e, "i": self.i,
            "Omega": self.Omega, "omega_arg": self.omega_arg,
            "p": self.p, "T_days": self.T_orb / 86400.0,
        }
