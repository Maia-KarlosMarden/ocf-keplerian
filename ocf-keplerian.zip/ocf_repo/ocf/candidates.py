"""
candidates.py — Generate and manage candidate orbit ensembles.

Replicates the IOD → ensemble generation stage that precedes OCF filtering.
The ensemble spans the admissible parameter space around a nominal solution.
"""

import numpy as np
from dataclasses import dataclass
from .propagator import KeplerPropagator
from .keplerian import AU, M_SUN


@dataclass
class CandidateOrbit:
    """Named container for orbital elements + propagator."""
    id:   int
    a:    float      # semi-major axis [m]
    e:    float      # eccentricity
    i:    float      # inclination [rad]
    prop: KeplerPropagator = None

    def __post_init__(self):
        if self.prop is None:
            self.prop = KeplerPropagator(self.a, self.e, self.i)

    @property
    def a_AU(self) -> float:
        return self.a / AU


def generate_ensemble(
    a_true: float,
    e_true: float,
    i_true: float = 0.0,
    n_candidates: int = 500,
    a_spread_AU: float = 0.15,
    e_spread: float = 0.10,
    i_spread_rad: float = 0.05,
    M0_spread: float = 2 * np.pi,
    seed: int = 42,
    include_true: bool = True,
    true_id: int = 0,
    M_central: float = M_SUN,
) -> tuple[list[KeplerPropagator], int]:
    """
    Generate an ensemble of candidate orbits around a known true solution.

    Parameters
    ----------
    a_true, e_true, i_true : true orbital elements
    n_candidates  : total number of candidates (including true if include_true)
    a_spread_AU   : ±half-width of uniform spread in semi-major axis [AU]
    e_spread      : ±half-width for eccentricity
    i_spread_rad  : ±half-width for inclination [rad]
    M0_spread     : ±half-width for mean anomaly at epoch [rad] (default full 2π)
    seed          : RNG seed
    include_true  : whether to inject the true orbit as candidate #true_id
    true_id       : index of the true orbit in the returned list

    Returns
    -------
    (candidates: list[KeplerPropagator], true_index: int)
    """
    rng = np.random.default_rng(seed)

    a_spread = a_spread_AU * AU
    n_gen    = n_candidates - 1 if include_true else n_candidates

    a_vals  = a_true  + rng.uniform(-a_spread,       a_spread,       n_gen)
    e_vals  = e_true  + rng.uniform(-e_spread,        e_spread,       n_gen)
    i_vals  = i_true  + rng.uniform(-i_spread_rad,    i_spread_rad,   n_gen)
    M0_vals = rng.uniform(0.0, M0_spread, n_gen)

    # Clip to physical bounds
    e_vals = np.clip(e_vals, 1e-4, 0.9999)
    a_vals = np.clip(a_vals, 0.01 * AU, 100.0 * AU)
    i_vals = np.clip(i_vals, 0.0, np.pi)

    candidates = []
    for j in range(n_gen):
        prop = KeplerPropagator(a_vals[j], e_vals[j], i_vals[j],
                                 M0=M0_vals[j], M_central=M_central)
        candidates.append(prop)

    if include_true:
        true_prop = KeplerPropagator(a_true, e_true, i_true,
                                      M0=0.0, M_central=M_central)
        candidates.insert(true_id, true_prop)
        return candidates, true_id

    return candidates, -1
