"""
filters.py — OCF filtering and chi-squared threshold (Eq. 10 of Maia 2026).

Retain candidates satisfying:
    OCF(O_k) < ε,   ε = σ² · χ²_α(N_obs)
"""

import numpy as np
from scipy.stats import chi2
from .ocf import OCFResult


def ocf_threshold(sigma: float, n_obs: int, alpha: float = 0.997) -> float:
    """
    Compute the OCF acceptance threshold ε = σ² · χ²_α(N_obs).

    Parameters
    ----------
    sigma : float  — measurement noise std on K (dimensionless)
    n_obs : int    — number of observation epochs
    alpha : float  — confidence level (default 0.997 ≈ 3σ)

    Returns
    -------
    epsilon : float — OCF threshold
    """
    chi2_val = chi2.ppf(alpha, df=n_obs)
    return sigma**2 * chi2_val


def filter_candidates(results: list[OCFResult],
                       sigma: float = 1e-6,
                       n_obs: int | None = None,
                       alpha: float = 0.997,
                       epsilon: float | None = None) -> tuple[list[OCFResult], float]:
    """
    Apply OCF filtering to a ranked list of candidates.

    Parameters
    ----------
    results   : sorted list of OCFResult (from compute_ocf_ensemble)
    sigma     : noise std on K for threshold calculation
    n_obs     : number of observations (inferred from results[0] if None)
    alpha     : confidence level
    epsilon   : manual threshold override (bypasses chi² calculation)

    Returns
    -------
    (survivors: list[OCFResult], threshold: float)
    """
    if epsilon is None:
        n = n_obs if n_obs is not None else results[0].n_epochs
        epsilon = ocf_threshold(sigma, n, alpha)

    survivors = [r for r in results if r.ocf_value < epsilon]
    return survivors, epsilon


def reduction_stats(all_results: list[OCFResult],
                    survivors: list[OCFResult],
                    true_id: int = 0) -> dict:
    """
    Compute filtering statistics matching Table 2 of Maia (2026).

    Parameters
    ----------
    all_results : full ranked list
    survivors   : filtered list
    true_id     : candidate_id of the true orbit

    Returns
    -------
    dict with reduction ratio, true orbit rank, pass/fail
    """
    n_total    = len(all_results)
    n_survive  = len(survivors)

    true_result = next((r for r in all_results if r.candidate_id == true_id), None)
    true_rank   = true_result.rank if true_result else None
    true_ocf    = true_result.ocf_value if true_result else None
    true_passed = any(r.candidate_id == true_id for r in survivors)

    return {
        "n_total":        n_total,
        "n_survivors":    n_survive,
        "reduction_pct":  100.0 * (1 - n_survive / n_total),
        "true_rank":      true_rank,
        "true_ocf":       true_ocf,
        "true_passed":    true_passed,
    }
