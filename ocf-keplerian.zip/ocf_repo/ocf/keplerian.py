"""
keplerian.py — Foundational Keplerian identities from Maia (2026).

The three-way identity:
    K = G'/G = p/r = 1 + e·cos(θ)

G' is NOT a new physical constant — it is angular momentum conservation
expressed in gravitational units, as a local (pointwise) quantity.
"""

import numpy as np

# SI constants
G_NEWTON = 6.6743e-11   # m³ kg⁻¹ s⁻²
M_SUN    = 1.989e30     # kg
AU       = 1.496e11     # m


def keplerian_index_from_dynamics(omega: float, r: float, M: float = M_SUN) -> float:
    """
    K = G'/G,  where  G' ≡ ω²r³/M.

    Parameters
    ----------
    omega : float  — instantaneous angular velocity [rad/s]
    r     : float  — heliocentric distance [m]
    M     : float  — central body mass [kg]

    Returns
    -------
    K : float  — dimensionless Keplerian index
    """
    G_prime = (omega**2 * r**3) / M
    return G_prime / G_NEWTON


def keplerian_index_from_geometry(p: float, r: float) -> float:
    """
    K = p/r   (geometric form).

    Parameters
    ----------
    p : float — semi-latus rectum [m]
    r : float — instantaneous heliocentric distance [m]
    """
    return p / r


def keplerian_index_from_kinematics(e: float, theta: float) -> float:
    """
    K = 1 + e·cos(θ)   (kinematic form).

    Parameters
    ----------
    e     : float — orbital eccentricity
    theta : float — true anomaly [radians]
    """
    return 1.0 + e * np.cos(theta)


class KeplerianIndex:
    """
    Encapsulates the three-way Keplerian index and verifies internal consistency.

    Usage
    -----
    ki = KeplerianIndex(e=0.1912, a=0.9224*AU)
    K  = ki.at_theta(np.radians(120.703))
    """

    def __init__(self, e: float, a: float, M: float = M_SUN):
        """
        Parameters
        ----------
        e : eccentricity
        a : semi-major axis [m]
        M : central mass [kg]
        """
        self.e = e
        self.a = a
        self.M = M
        self.p = a * (1.0 - e**2)            # semi-latus rectum
        self.h = np.sqrt(G_NEWTON * M * self.p)  # specific angular momentum

    def at_theta(self, theta: float) -> float:
        """Return K at true anomaly theta [rad]."""
        return keplerian_index_from_kinematics(self.e, theta)

    def radius_at_theta(self, theta: float) -> float:
        """Instantaneous heliocentric distance [m]."""
        return self.p / (1.0 + self.e * np.cos(theta))

    def omega_at_theta(self, theta: float) -> float:
        """Instantaneous angular velocity [rad/s] via h = r²ω."""
        r = self.radius_at_theta(theta)
        return self.h / r**2

    def G_prime_at_theta(self, theta: float) -> float:
        """Local gravitational coupling G' [m³ kg⁻¹ s⁻²]."""
        omega = self.omega_at_theta(theta)
        r     = self.radius_at_theta(theta)
        return (omega**2 * r**3) / self.M

    def verify_invariant(self, theta: float, tol: float = 1e-4) -> dict:
        """
        Verify G'·r = G·p at given theta.

        Returns dict with both sides and relative discrepancy.
        """
        G_prime = self.G_prime_at_theta(theta)
        r       = self.radius_at_theta(theta)
        lhs     = G_prime * r
        rhs     = G_NEWTON * self.p
        rel_err = abs(lhs - rhs) / rhs
        return {
            "G_prime_r": lhs,
            "G_p":       rhs,
            "rel_error": rel_err,
            "passes":    rel_err < tol,
        }

    def period(self) -> float:
        """Orbital period [s] via Kepler III."""
        return 2 * np.pi * np.sqrt(self.a**3 / (G_NEWTON * self.M))


def relational_invariant(a: float, e: float, theta_values,
                          M: float = M_SUN) -> np.ndarray:
    """
    Compute G'·r at each true anomaly in theta_values.

    Ideal value is G·p everywhere — use this to verify a numerical propagator
    or to audit a set of observational states.

    Returns
    -------
    Array of G'·r values [m⁴ kg⁻¹ s⁻²], one per theta.
    """
    ki      = KeplerianIndex(e, a, M)
    thetas  = np.atleast_1d(theta_values)
    results = np.array([ki.G_prime_at_theta(t) * ki.radius_at_theta(t)
                        for t in thetas])
    return results


def derive_elements_from_single_obs(r: float, omega: float,
                                    theta: float, M: float = M_SUN) -> dict:
    """
    Derive eccentricity and semi-major axis from a single instantaneous observation
    (Section 4 of Maia 2026).

    Parameters
    ----------
    r     : heliocentric distance [m]
    omega : instantaneous angular velocity [rad/s]
    theta : true anomaly [rad]  — must be known independently
    M     : central mass [kg]

    Returns
    -------
    dict with e, a, p, T_days
    """
    K = (omega**2 * r**3) / (G_NEWTON * M)
    e = (K - 1.0) / np.cos(theta)
    a = K * r / (1.0 - e**2)
    p = a * (1.0 - e**2)
    T = 2 * np.pi * np.sqrt(a**3 / (G_NEWTON * M))
    return {
        "K": K, "e": e, "a": a, "p": p,
        "a_AU": a / AU,
        "T_days": T / 86400.0,
    }
