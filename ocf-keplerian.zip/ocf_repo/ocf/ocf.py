"""
ocf.py — Orbital Coherence Function (Eq. 9 of Maia 2026).

OCF(O_k) = Σ_i [ p_k/r_{k,i}  −  K_{θ,k}(t_i)  −  δ_ref(t_i) ]²

Correct physical interpretation
--------------------------------
At each epoch t_i, the *observed* state (from the TRUE orbit or actual
measurements) gives an observed Keplerian index:

    K_obs(t_i) = p_true / r_true(t_i)

A CANDIDATE orbit O_k propagated to the same epoch gives a *predicted* K:

    K_pred_k(t_i) = p_k / r_{k,i}  OR equivalently  1 + e_k·cos(θ_{k,i})

The OCF accumulates the squared mismatch between K_obs and K_pred:

    OCF(O_k) = Σ_i [ K_obs(t_i) − K_pred_k(t_i) − δ_ref(t_i) ]²

For the true orbit:  K_obs ≡ K_pred  →  OCF = 0 exactly.
For false candidates: K_obs ≠ K_pred  →  OCF > 0, growing with arc length.

δ_ref performs common-mode subtraction of the Gauss/IOD nominal orbit,
removing systematic biases shared by all candidates without altering
relative ranking.
"""

import numpy as np
from dataclasses import dataclass
from typing import Sequence
from .propagator import KeplerPropagator


@dataclass
class OCFResult:
    candidate_id: int
    ocf_value: float
    residuals: np.ndarray          # per-epoch residuals (before squaring)
    n_epochs: int
    rank: int = -1                 # filled in by compute_ocf_ensemble

    @property
    def rms_residual(self) -> float:
        return float(np.sqrt(np.mean(self.residuals**2)))

    def __lt__(self, other):
        return self.ocf_value < other.ocf_value


class OCF:
    """
    Orbital Coherence Function evaluator for a single candidate orbit.

    Parameters
    ----------
    candidate   : KeplerPropagator — the candidate orbit being tested
    true_prop   : KeplerPropagator — source of observed K values
                  (represents actual measurements or the nominal orbit)
    ref_prop    : KeplerPropagator | None — nominal orbit for δ_ref
                  common-mode subtraction. If None, δ_ref = 0.
    """

    def __init__(self, candidate: KeplerPropagator,
                 true_prop: KeplerPropagator | None = None,
                 ref_prop: KeplerPropagator | None = None):
        self.cand     = candidate
        self.true_prop = true_prop   # source of K_obs
        self.ref_prop  = ref_prop

    def _K_observed(self, t: float) -> float:
        """
        K observed from the true orbit (or actual measurement) at epoch t.
        K_obs = p_true / r_true(t).
        """
        if self.true_prop is None:
            raise ValueError("true_prop required to compute K_obs. "
                             "Pass the true (or reference measurement) propagator.")
        s = self.true_prop.state_at(t)
        return s["K"]   # = p/r for the true orbit

    def _K_predicted(self, t: float) -> float:
        """
        K predicted by the candidate orbit at epoch t.
        K_pred = 1 + e_k * cos(θ_k(t)).
        """
        s = self.cand.state_at(t)
        return 1.0 + self.cand.e * np.cos(s["theta"])

    def _delta_ref(self, t: float) -> float:
        """
        Common-mode correction δ_ref(t).
        Defined as: K_obs_ref(t) − K_pred_ref(t) for the nominal Gauss orbit.
        For a perfect Keplerian nominal orbit this is 0 by construction;
        in practice it absorbs shared systematic biases.
        """
        if self.ref_prop is None:
            return 0.0
        K_obs_ref  = self.true_prop.state_at(t)["K"]  if self.true_prop else 0.0
        K_pred_ref = 1.0 + self.ref_prop.e * np.cos(self.ref_prop.state_at(t)["theta"])
        return K_obs_ref - K_pred_ref

    def evaluate(self, obs_times: Sequence[float],
                 candidate_id: int = 0) -> OCFResult:
        """
        Compute OCF for this candidate over the given observation epochs.

        Parameters
        ----------
        obs_times    : array-like of floats [s from reference epoch]
        candidate_id : integer label

        Returns
        -------
        OCFResult
        """
        residuals = []
        for t in obs_times:
            K_obs   = self._K_observed(t)
            K_pred  = self._K_predicted(t)
            delta   = self._delta_ref(t)
            res     = K_obs - K_pred - delta
            residuals.append(res)

        residuals = np.array(residuals)
        ocf_val   = float(np.sum(residuals**2))

        return OCFResult(
            candidate_id=candidate_id,
            ocf_value=ocf_val,
            residuals=residuals,
            n_epochs=len(obs_times),
        )


def compute_ocf_ensemble(candidates: list[KeplerPropagator],
                          obs_times: Sequence[float],
                          ref_propagator: KeplerPropagator | None = None,
                          true_propagator: KeplerPropagator | None = None,
                          noise_sigma: float = 0.0,
                          seed: int | None = None) -> list[OCFResult]:
    """
    Evaluate OCF for an ensemble of candidate orbits.

    Parameters
    ----------
    candidates      : list of KeplerPropagator objects (the ensemble)
    obs_times       : observation epochs [s from reference epoch]
    ref_propagator  : nominal (Gauss) orbit for common-mode subtraction.
                      Also used as the source of K_obs if true_propagator
                      is not provided.
    true_propagator : the TRUE orbit (source of observed K values).
                      If None, ref_propagator is used as truth.
    noise_sigma     : Gaussian noise std on K_obs (0 = perfect measurements)
    seed            : random seed for reproducibility

    Returns
    -------
    List of OCFResult, sorted by OCF value ascending (best candidate first).
    """
    rng = np.random.default_rng(seed)

    # Resolve truth source
    truth = true_propagator if true_propagator is not None else ref_propagator
    if truth is None:
        raise ValueError("Provide ref_propagator or true_propagator as the "
                         "source of observed K values.")

    # Pre-compute K_obs at all epochs (with optional noise)
    obs_times = np.asarray(obs_times)
    K_obs_arr = np.array([truth.state_at(t)["K"] for t in obs_times])
    if noise_sigma > 0:
        K_obs_arr = K_obs_arr + rng.normal(0.0, noise_sigma, len(obs_times))

    results = []
    for k, cand in enumerate(candidates):
        residuals = np.array([
            K_obs_arr[i] - (1.0 + cand.e * np.cos(cand.state_at(t)["theta"]))
            for i, t in enumerate(obs_times)
        ])
        ocf_val = float(np.sum(residuals**2))
        results.append(OCFResult(
            candidate_id=k,
            ocf_value=ocf_val,
            residuals=residuals,
            n_epochs=len(obs_times),
        ))

    # Rank by OCF value
    results.sort()
    for rank, r in enumerate(results):
        r.rank = rank + 1

    return results
