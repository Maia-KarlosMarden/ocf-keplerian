"""
tests/test_ocf.py — Tests for the OCF computation and filtering pipeline.
"""

import numpy as np
import pytest
from ocf import compute_ocf_ensemble, generate_ensemble, filter_candidates
from ocf.filters import reduction_stats
from ocf.keplerian import AU
from ocf.propagator import KeplerPropagator

A_TRUE = 0.9224 * AU
E_TRUE = 0.1912
I_TRUE = np.radians(3.33)
OBS_30 = np.linspace(0.0, 30 * 86400.0, 30)


class TestOCFTrueOrbit:
    """The true orbit must return OCF = 0 in the noise-free case."""

    def test_true_orbit_ocf_zero(self):
        true_prop = KeplerPropagator(A_TRUE, E_TRUE, I_TRUE)
        from ocf.ocf import OCF
        evaluator = OCF(candidate=true_prop, true_prop=true_prop)
        result = evaluator.evaluate(OBS_30, candidate_id=0)
        assert result.ocf_value < 1e-20, f"OCF = {result.ocf_value:.3e} (expected 0)"

    def test_true_orbit_rank_1(self):
        candidates, true_idx = generate_ensemble(
            A_TRUE, E_TRUE, I_TRUE, n_candidates=50, seed=42
        )
        results = compute_ocf_ensemble(
            candidates, OBS_30,
            ref_propagator=candidates[true_idx],
            noise_sigma=0.0,
        )
        assert results[0].candidate_id == true_idx, \
            f"True orbit rank = {results[0].rank}, expected #1"


class TestEnsembleFiltering:
    """Filtering should remove false candidates while retaining true orbit."""

    def test_reduction_exceeds_90pct(self):
        candidates, true_idx = generate_ensemble(
            A_TRUE, E_TRUE, I_TRUE, n_candidates=200, seed=42
        )
        results   = compute_ocf_ensemble(candidates, OBS_30,
                                          ref_propagator=candidates[true_idx],
                                          noise_sigma=0.0)
        survivors, _ = filter_candidates(results, sigma=1e-6, n_obs=30)
        stats = reduction_stats(results, survivors, true_id=true_idx)
        assert stats["reduction_pct"] > 90.0

    def test_true_orbit_survives_filter(self):
        candidates, true_idx = generate_ensemble(
            A_TRUE, E_TRUE, I_TRUE, n_candidates=200, seed=42
        )
        results   = compute_ocf_ensemble(candidates, OBS_30,
                                          ref_propagator=candidates[true_idx],
                                          noise_sigma=0.0)
        survivors, _ = filter_candidates(results, sigma=1e-6, n_obs=30)
        stats = reduction_stats(results, survivors, true_id=true_idx)
        assert stats["true_passed"], "True orbit was filtered out — should never happen."


class TestOCFScaling:
    """OCF should grow with false candidates as arc length increases."""

    def test_false_candidate_ocf_increases_with_arc(self):
        """A random false orbit should accumulate more OCF over a longer arc."""
        true_prop  = KeplerPropagator(A_TRUE, E_TRUE, I_TRUE)
        false_prop = KeplerPropagator(A_TRUE * 1.05, E_TRUE + 0.05)
        from ocf.ocf import OCF
        evaluator  = OCF(candidate=false_prop, true_prop=true_prop)
        ocf_short  = evaluator.evaluate(np.linspace(0, 10 * 86400, 10)).ocf_value
        ocf_long   = evaluator.evaluate(np.linspace(0, 30 * 86400, 30)).ocf_value
        assert ocf_long > ocf_short, "OCF should grow with more epochs for false orbit"


class TestFullApophis500:
    """Reproduce Table 2: 500 candidates, 30-day arc, ideal conditions."""

    def test_table2_reduction(self):
        candidates, true_idx = generate_ensemble(
            A_TRUE, E_TRUE, I_TRUE, n_candidates=500, seed=42
        )
        results = compute_ocf_ensemble(candidates, OBS_30,
                                        ref_propagator=candidates[true_idx],
                                        noise_sigma=0.0)
        survivors, _ = filter_candidates(results, sigma=1e-6, n_obs=30)
        stats = reduction_stats(results, survivors, true_id=true_idx)

        assert stats["true_rank"] == 1,         "True orbit must rank #1"
        assert stats["true_passed"],             "True orbit must survive filter"
        assert stats["reduction_pct"] > 90.0,   "Reduction must exceed 90%"
