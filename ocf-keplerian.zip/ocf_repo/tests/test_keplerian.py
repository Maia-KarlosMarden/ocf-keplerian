"""
tests/test_keplerian.py — Unit tests for the foundational Keplerian identities.
"""

import numpy as np
import pytest
from ocf.keplerian import (
    KeplerianIndex, relational_invariant,
    keplerian_index_from_dynamics, keplerian_index_from_geometry,
    keplerian_index_from_kinematics, derive_elements_from_single_obs,
    G_NEWTON, M_SUN, AU,
)

# Apophis parameters (Section 4 of paper)
A_APOPHIS = 0.9224 * AU
E_APOPHIS = 0.1912

# Mercury parameters (Section 3 of paper)
A_MERCURY = 5.79e10
E_MERCURY = 0.20553


class TestRelationalInvariant:
    """G'·r = G·p at every orbital point."""

    def test_mercury_perihelion(self):
        ki = KeplerianIndex(E_MERCURY, A_MERCURY)
        v  = ki.verify_invariant(0.0)
        assert v["passes"], f"rel_error = {v['rel_error']:.4e}"

    def test_mercury_aphelion(self):
        ki = KeplerianIndex(E_MERCURY, A_MERCURY)
        v  = ki.verify_invariant(np.pi)
        assert v["passes"]

    def test_mercury_theta150(self):
        ki = KeplerianIndex(E_MERCURY, A_MERCURY)
        v  = ki.verify_invariant(np.radians(150))
        assert v["passes"]

    def test_apophis_multiple_positions(self):
        ki     = KeplerianIndex(E_APOPHIS, A_APOPHIS)
        thetas = np.linspace(0, 2 * np.pi, 36, endpoint=False)
        for th in thetas:
            v = ki.verify_invariant(th)
            assert v["passes"], f"Failed at θ={np.degrees(th):.1f}°, err={v['rel_error']:.4e}"


class TestThreeWayIdentity:
    """K_dynamics = K_geometry = K_kinematics (Eq. 8 of paper)."""

    @pytest.mark.parametrize("theta_deg", [0, 45, 90, 120, 150, 180, 270])
    def test_three_forms_agree(self, theta_deg):
        theta = np.radians(theta_deg)
        ki    = KeplerianIndex(E_APOPHIS, A_APOPHIS)

        K_kin  = keplerian_index_from_kinematics(E_APOPHIS, theta)
        K_geom = keplerian_index_from_geometry(ki.p, ki.radius_at_theta(theta))
        K_dyn  = keplerian_index_from_dynamics(ki.omega_at_theta(theta),
                                                ki.radius_at_theta(theta))

        assert abs(K_kin - K_geom) < 1e-10, f"kin≠geom at θ={theta_deg}°"
        assert abs(K_kin - K_dyn)  < 1e-6,  f"kin≠dyn at θ={theta_deg}°"


class TestKeplerianIndexBounds:
    """Verify K ∈ [1−e, 1+e] and equals 1 at semi-latus rectum crossings."""

    def test_perihelion_maximum(self):
        ki = KeplerianIndex(E_APOPHIS, A_APOPHIS)
        assert abs(ki.at_theta(0.0) - (1 + E_APOPHIS)) < 1e-10

    def test_aphelion_minimum(self):
        ki = KeplerianIndex(E_APOPHIS, A_APOPHIS)
        assert abs(ki.at_theta(np.pi) - (1 - E_APOPHIS)) < 1e-10

    def test_semi_latus_rectum_crossing(self):
        ki = KeplerianIndex(E_APOPHIS, A_APOPHIS)
        assert abs(ki.at_theta(np.pi / 2) - 1.0) < 1e-10


class TestSingleObsDerivation:
    """Reproduce Section 4 of the paper: derive elements from one observation."""

    def test_apophis_eccentricity_recovery(self):
        ki    = KeplerianIndex(E_APOPHIS, A_APOPHIS)
        theta = np.radians(120.703)
        r     = ki.radius_at_theta(theta)
        omega = ki.omega_at_theta(theta)

        derived = derive_elements_from_single_obs(r, omega, theta)
        assert abs(derived["e"] - E_APOPHIS) < 1e-4, \
            f"e recovered = {derived['e']:.6f}, true = {E_APOPHIS}"

    def test_apophis_semimajor_recovery(self):
        ki    = KeplerianIndex(E_APOPHIS, A_APOPHIS)
        theta = np.radians(120.703)
        r     = ki.radius_at_theta(theta)
        omega = ki.omega_at_theta(theta)

        derived = derive_elements_from_single_obs(r, omega, theta)
        assert abs(derived["a_AU"] - 0.9224) < 1e-3, \
            f"a recovered = {derived['a_AU']:.5f} AU, true = 0.9224 AU"


class TestRelationalInvariantBroadSweep:
    """relational_invariant() convenience function."""

    def test_constant_over_full_orbit(self):
        thetas = np.linspace(0, 2 * np.pi, 100, endpoint=False)
        values = relational_invariant(A_APOPHIS, E_APOPHIS, thetas)
        expected = G_NEWTON * A_APOPHIS * (1 - E_APOPHIS**2)
        rel_err  = np.abs(values - expected) / expected
        assert np.all(rel_err < 1e-8)
