"""
benchmark_apophis.py — Reproduces the Apophis synthetic validation (Table 2)
from Maia (2026): "The Orbital Coherence Function."

Expected output (ideal, no noise):
    Candidates: 500
    Survivors:   22  (±few depending on spread sampling)
    True rank:    1  (OCF = 0)
    Reduction:  ~95.6%
    Arc:        30 days
"""

import time
import numpy as np
from ocf import compute_ocf_ensemble, generate_ensemble, filter_candidates
from ocf.filters import reduction_stats
from ocf.keplerian import AU

# ─── Apophis (99942) true orbital elements ──────────────────────────────────
A_TRUE  = 0.9224 * AU    # semi-major axis [m]
E_TRUE  = 0.1912         # eccentricity
I_TRUE  = np.radians(3.33)  # inclination [rad]

# ─── Observational arc ──────────────────────────────────────────────────────
ARC_DAYS   = 30
N_OBS      = 30           # one observation per day
OBS_TIMES  = np.linspace(0.0, ARC_DAYS * 86400.0, N_OBS)  # [s]

# ─── Ensemble configuration ─────────────────────────────────────────────────
N_CANDIDATES = 500
NOISE_SIGMA  = 0.0        # ideal two-body: no noise
SEED         = 42


def run_benchmark(n_candidates: int = N_CANDIDATES,
                  arc_days: int = ARC_DAYS,
                  n_obs: int = N_OBS,
                  noise_sigma: float = NOISE_SIGMA,
                  seed: int = SEED,
                  verbose: bool = True) -> dict:
    """
    Run the Apophis benchmark and return a statistics dict.

    Parameters mirror the paper's Table 2 configuration.
    """
    obs_times = np.linspace(0.0, arc_days * 86400.0, n_obs)

    # 1. Generate ensemble
    t0 = time.perf_counter()
    candidates, true_idx = generate_ensemble(
        a_true=A_TRUE, e_true=E_TRUE, i_true=I_TRUE,
        n_candidates=n_candidates,
        a_spread_AU=0.15, e_spread=0.10,
        seed=seed, include_true=True, true_id=0,
    )

    # 2. Compute OCF for all candidates
    results = compute_ocf_ensemble(
        candidates, obs_times,
        ref_propagator=candidates[true_idx],
        noise_sigma=noise_sigma, seed=seed,
    )
    elapsed = time.perf_counter() - t0

    # 3. Filter
    survivors, epsilon = filter_candidates(results, sigma=1e-6, n_obs=n_obs)
    stats = reduction_stats(results, survivors, true_id=true_idx)

    if verbose:
        print("\n" + "="*55)
        print("  OCF Benchmark — Apophis (99942) — Maia (2026)")
        print("="*55)
        print(f"  Candidates generated : {n_candidates}")
        print(f"  Observational arc    : {arc_days} days  ({n_obs} epochs)")
        print(f"  Noise σ(K)           : {noise_sigma:.1e}")
        print(f"  Computation time     : {elapsed:.1f} s")
        print("-"*55)
        print(f"  Survivors after OCF  : {stats['n_survivors']}")
        print(f"  Candidate reduction  : {stats['reduction_pct']:.1f}%")
        print(f"  True orbit rank      : #{stats['true_rank']}")
        print(f"  True orbit OCF       : {stats['true_ocf']:.2e}")
        print(f"  True orbit passed    : {stats['true_passed']}")
        print("="*55)

        # Compare with paper claims
        print("\n  Paper claims (Table 2):")
        print("    Reduction : 95.6% →", "✓" if stats['reduction_pct'] > 90 else "✗")
        print("    True rank : #1    →", "✓" if stats['true_rank'] == 1 else "✗")
        print()

    stats["elapsed_s"]   = elapsed
    stats["epsilon"]     = epsilon
    stats["arc_days"]    = arc_days
    stats["n_obs"]       = n_obs
    stats["noise_sigma"] = noise_sigma
    return stats


if __name__ == "__main__":
    run_benchmark()
