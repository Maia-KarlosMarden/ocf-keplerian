"""
arc_sensitivity.py — Investigates how OCF filtering performance varies
with observational arc length (5 to 90 days).

Reproduces the core claim of Maia (2026): convergence at 30 days
vs ~90 days for traditional methods.
"""

import numpy as np
import time
from ocf import compute_ocf_ensemble, generate_ensemble, filter_candidates
from ocf.filters import reduction_stats
from ocf.keplerian import AU

A_TRUE = 0.9224 * AU
E_TRUE = 0.1912
I_TRUE = np.radians(3.33)

ARC_LENGTHS_DAYS = [5, 10, 15, 20, 25, 30, 45, 60, 90]
N_CANDIDATES     = 500
SEED             = 42


def run():
    print("\nOCF Arc-Length Sensitivity")
    print("="*65)
    print(f"  {'Arc (days)':<12} {'Survivors':<12} {'Reduction %':<14} {'True rank':<12} {'Time (s)'}")
    print("-"*65)

    candidates, true_idx = generate_ensemble(
        A_TRUE, E_TRUE, I_TRUE,
        n_candidates=N_CANDIDATES, seed=SEED, include_true=True, true_id=0,
    )

    for arc in ARC_LENGTHS_DAYS:
        n_obs     = max(arc, 5)
        obs_times = np.linspace(0.0, arc * 86400.0, n_obs)

        t0      = time.perf_counter()
        results = compute_ocf_ensemble(candidates, obs_times,
                                        ref_propagator=candidates[true_idx],
                                        noise_sigma=0.0, seed=SEED)
        elapsed = time.perf_counter() - t0

        survivors, _ = filter_candidates(results, sigma=1e-6, n_obs=n_obs)
        stats        = reduction_stats(results, survivors, true_id=true_idx)

        print(f"  {arc:<12} {stats['n_survivors']:<12} {stats['reduction_pct']:<14.1f} "
              f"#{stats['true_rank']:<11} {elapsed:.1f}")

    print("="*65)
    print("\n  Target (Maia 2026): reduction >95% at 30 days, true rank = #1")
    print()


if __name__ == "__main__":
    run()
