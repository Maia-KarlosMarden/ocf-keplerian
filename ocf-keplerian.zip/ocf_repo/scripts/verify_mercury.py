"""
verify_mercury.py — Reproduces Table 1 of Maia (2026):
Numerical verification of the relational invariant G'·r = G·p for Mercury.
"""

import numpy as np
from ocf.keplerian import KeplerianIndex, G_NEWTON, M_SUN

def main():
    # Mercury orbital parameters
    a = 5.79e10    # m
    e = 0.20553
    ki = KeplerianIndex(e, a, M_SUN)

    print("\nVerification of G'·r = G·p  [Mercury]")
    print("="*60)
    print(f"  a = {a:.3e} m,  e = {e},  p = {ki.p:.4e} m")
    print(f"  G·p (global) = {G_NEWTON * ki.p:.4f} m⁴ kg⁻¹ s⁻²")
    print("-"*60)
    print(f"  {'Position':<18} {'G′ (×10⁻¹¹)':<18} {'r (×10¹⁰ m)':<16} {'G′·r':<12}")
    print("-"*60)

    positions = [("Perihelion (θ=0°)", 0.0),
                 ("θ = 150°",          np.radians(150)),
                 ("Aphelion (θ=180°)", np.pi)]

    for name, theta in positions:
        r       = ki.radius_at_theta(theta)
        G_prime = ki.G_prime_at_theta(theta)
        product = G_prime * r
        print(f"  {name:<18} {G_prime*1e11:>10.3f}      {r/1e10:>10.3f}       {product:.4f}")

    print("-"*60)
    print(f"  {'Global (G, p)':<18} {G_NEWTON*1e11:>10.4f}      {ki.p/1e10:>10.3f}       {G_NEWTON*ki.p:.4f}")
    print()

    # Relative errors
    for name, theta in positions:
        v = ki.verify_invariant(theta)
        print(f"  {name}: rel. error = {v['rel_error']*100:.3f}%  {'✓' if v['passes'] else '✗'}")
    print()

if __name__ == "__main__":
    main()
