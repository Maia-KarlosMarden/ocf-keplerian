# OCF — Theoretical Background

## Derivation of the Relational Invariant

Starting from Kepler III: ω²a³ = GM.

Define the instantaneous coupling at radius r:

    G' ≡ ω²r³/M

Since ω = h/r² (angular momentum h):

    G' = h²/(Mr)

For elliptical orbits, h² = GMp, so:

    G'·r = h²/M = G·p    ← the relational invariant

## The Three-Way Identity

From G'·r = G·p:

    G'/G = p/r

From the conic equation r = p/(1 + e·cos θ):

    p/r = 1 + e·cos θ

Therefore:

    K ≡ G'/G = p/r = 1 + e·cos θ

**Physical reading:** K is simultaneously a dynamical ratio (instantaneous
coupling vs Newton's constant), a geometric ratio (semi-latus rectum vs
instantaneous radius), and a kinematic expression (eccentricity + position).

## Appendix A Integrals of K(θ)

Time-uniform mean (weight dt/dθ ∝ r² ∝ (1+e·cosθ)⁻²):

    ⟨K⟩_t = 1 − e²

Mean in true anomaly:

    ⟨K⟩_θ = 1

These provide checks for any numerical propagator over a complete orbit.

## Perturbed Extension (Eq. 11)

    OCF_pert(O_k) = Σ_i [ p_k/r_{k,i} − K_{θ,k}(t_i) − δ_ref(t_i) − δ_pert(t_i) ]²

δ_pert encodes the perturbation-induced deviation from ideal Keplerian K,
computed from an n-body or force-model propagator.
